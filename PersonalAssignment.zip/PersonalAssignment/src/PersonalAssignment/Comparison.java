package PersonalAssignment;


public class Comparison {

    public static void main(String[] args) {

        int[] array = {10,20,30,40,50};

        System.out.println("===== ARRAY =====");
        System.out.print("Traversal : ");
        ArrayOperations.traversal(array);

        long start = System.nanoTime();
        int index = ArrayOperations.linearSearch(array,30);
        long end = System.nanoTime();

        System.out.println("Linear Search 30 : Index " + index);
        System.out.println("Waktu : " + (end-start) + " ns");

        start = System.nanoTime();
        array = ArrayOperations.insert(array,25,2);
        end = System.nanoTime();

        System.out.print("Insert 25 : ");
        ArrayOperations.traversal(array);
        System.out.println("Waktu : " + (end-start) + " ns");

        start = System.nanoTime();
        array = ArrayOperations.delete(array,2);
        end = System.nanoTime();

        System.out.print("Delete Index 2 : ");
        ArrayOperations.traversal(array);
        System.out.println("Waktu : " + (end-start) + " ns");


        System.out.println("\n===== ARRAYLIST =====");

        ArrayListOperations list = new ArrayListOperations();

        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);

        System.out.print("Traversal : ");
        list.display();

        start = System.nanoTime();
        index = list.search(30);
        end = System.nanoTime();

        System.out.println("Search 30 : Index " + index);
        System.out.println("Waktu : " + (end-start) + " ns");

        start = System.nanoTime();
        list.add(25);
        end = System.nanoTime();

        System.out.print("Tambah 25 : ");
        list.display();
        System.out.println("Waktu : " + (end-start) + " ns");

        start = System.nanoTime();
        list.remove(25);
        end = System.nanoTime();

        System.out.print("Hapus 25 : ");
        list.display();
        System.out.println("Waktu : " + (end-start) + " ns");

        start = System.nanoTime();
        list.sort();
        end = System.nanoTime();

        System.out.print("Sorting : ");
        list.display();
        System.out.println("Waktu : " + (end-start) + " ns");
    }
}