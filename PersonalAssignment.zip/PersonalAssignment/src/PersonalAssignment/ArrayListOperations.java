package PersonalAssignment;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListOperations {

    ArrayList<Integer> list = new ArrayList<>();

    public void add(int value) {
        list.add(value);
    }

    public void remove(int value) {
        list.remove(Integer.valueOf(value));
    }

    public int search(int value) {
        return list.indexOf(value);
    }

    public void sort() {
        Collections.sort(list);
    }

    public void display() {
        System.out.println(list);
    }
}