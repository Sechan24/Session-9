package Session9;

public class SinglyLinkedList {

    // Class Node
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    Node head = null;

    // ============================
    // Insert di Head
    // ============================
    public void insertHead(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }

    // ============================
    // Insert di Tail
    // ============================
    public void insertTail(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            return;
        }

        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }

        temp.next = newNode;
    }

    // ============================
    // Insert pada posisi tertentu
    // Posisi dimulai dari 1
    // ============================
    public void insertMiddle(int posisi, int data) {

        if (posisi <= 1) {
            insertHead(data);
            return;
        }

        Node newNode = new Node(data);
        Node temp = head;

        for (int i = 1; i < posisi - 1 && temp != null; i++) {
            temp = temp.next;
        }

        if (temp == null) {
            System.out.println("Posisi tidak ditemukan.");
            return;
        }

        newNode.next = temp.next;
        temp.next = newNode;
    }

    // ============================
    // Menampilkan Linked List
    // ============================
    public void display() {

        if (head == null) {
            System.out.println("Linked List kosong.");
            return;
        }

        Node temp = head;

        System.out.print("Linked List : ");

        while (temp != null) {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        }

        System.out.println("NULL");
    }

    // ============================
    // Main Program
    // ============================
    public static void main(String[] args) {

        SinglyLinkedList list = new SinglyLinkedList();

        // Insert di Head
        list.insertHead(20);
        list.insertHead(10);

        // Insert di Tail
        list.insertTail(40);
        list.insertTail(50);

        // Insert di Tengah (posisi ke-3)
        list.insertMiddle(3, 30);

        list.display();
    }
}