package Session9;

public class CircularLinkedList {

    // Class Node
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    // Head Circular Linked List
    Node head = null;

    // Menambah data di akhir Circular Linked List
    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else {
            Node temp = head;

            while (temp.next != head) {
                temp = temp.next;
            }

            temp.next = newNode;
            newNode.next = head;
        }
    }

    // Menampilkan isi Circular Linked List
    public void display() {
        if (head == null) {
            System.out.println("Circular Linked List Kosong");
            return;
        }

        Node temp = head;

        System.out.print("Isi Circular Linked List: ");

        do {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        } while (temp != head);

        System.out.println("(kembali ke Head)");
    }

    // Program Utama
    public static void main(String[] args) {

        CircularLinkedList list = new CircularLinkedList();

        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);
        list.insert(50);

        list.display();
    }
}