package Session9;

public class DeleteLinkedList {

    // Class Node
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    Node head = null;

    // Menambahkan node di akhir (Tail)
    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            return;
        }

        Node temp = head;

        while (temp.next != null) {
            temp = temp.next;
        }

        temp.next = newNode;
    }

    // ===============================
    // 1. Menghapus Node Pertama
    // ===============================
    public void removeFirst() {

        if (head == null) {
            System.out.println("Linked List kosong.");
            return;
        }

        head = head.next;
    }

    // ===============================
    // 2. Menghapus Node di Tengah
    // Posisi dimulai dari 1
    // ===============================
    public void removeMiddle(int posisi) {

        if (head == null) {
            System.out.println("Linked List kosong.");
            return;
        }

        if (posisi == 1) {
            removeFirst();
            return;
        }

        Node temp = head;

        for (int i = 1; i < posisi - 1 && temp.next != null; i++) {
            temp = temp.next;
        }

        if (temp.next == null) {
            System.out.println("Posisi tidak ditemukan.");
            return;
        }

        temp.next = temp.next.next;
    }

    // ===============================
    // 3. Menghapus Node Terakhir
    // ===============================
    public void removeLast() {

        if (head == null) {
            System.out.println("Linked List kosong.");
            return;
        }

        if (head.next == null) {
            head = null;
            return;
        }

        Node temp = head;

        while (temp.next.next != null) {
            temp = temp.next;
        }

        temp.next = null;
    }

    // Menampilkan isi Linked List
    public void display() {

        Node temp = head;

        System.out.print("Linked List : ");

        while (temp != null) {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        }

        System.out.println("NULL");
    }

    // Program Utama
    public static void main(String[] args) {

        DeleteLinkedList list = new DeleteLinkedList();

        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);
        list.insert(50);

        System.out.println("Data Awal");
        list.display();

        System.out.println("\nHapus Node Pertama");
        list.removeFirst();
        list.display();

        System.out.println("\nHapus Node Tengah (Posisi ke-2)");
        list.removeMiddle(2);
        list.display();

        System.out.println("\nHapus Node Terakhir");
        list.removeLast();
        list.display();
    }
}