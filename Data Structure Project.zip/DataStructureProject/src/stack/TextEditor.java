package stack;

import java.util.Stack;

public class TextEditor {

    private Stack<String> undoStack = new Stack<>();
    private Stack<String> redoStack = new Stack<>();

    private String text = "";

    // Menulis teks baru
    public void write(String newText) {

        undoStack.push(text);

        text = newText;

        redoStack.clear();

        System.out.println("Teks saat ini : " + text);
    }

    // Undo
    public void undo() {

        if (!undoStack.isEmpty()) {

            redoStack.push(text);

            text = undoStack.pop();

        }

        System.out.println("Undo : " + text);
    }

    // Redo
    public void redo() {

        if (!redoStack.isEmpty()) {

            undoStack.push(text);

            text = redoStack.pop();

        }

        System.out.println("Redo : " + text);
    }
}