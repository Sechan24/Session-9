import queue.CustomerQueue;
import stack.TextEditor;
import linkedlist.*;

public class Main {

    public static void main(String[] args) {

        System.out.println("===== QUEUE =====");

        CustomerQueue queue = new CustomerQueue();

        long start = System.nanoTime();

        queue.addCustomer("Aditya");
        queue.addCustomer("Gilang");
        queue.addCustomer("Fajar");

        queue.showQueue();

        queue.serveCustomer();

        queue.showQueue();

        long end = System.nanoTime();

        System.out.println("Waktu Queue : " + (end-start)+" ns");


        System.out.println("\n===== STACK =====");

        TextEditor editor = new TextEditor();

        start = System.nanoTime();

        editor.write("Selamat");

        editor.write("Selamat Datang");

        editor.undo();

        editor.redo();

        end = System.nanoTime();

        System.out.println("Waktu Stack : " + (end-start)+" ns");


        System.out.println("\n===== LINKED LIST =====");

        StudentLinkedList list = new StudentLinkedList();

        start = System.nanoTime();

        list.add(new Student("2902795211","Aditya",90));
        list.add(new Student("2902784896","Gilang",85));

        list.display();

        System.out.println("\nUpdate Nilai Gilang");

        list.update("2902784896",95);

        list.display();

        System.out.println("\nHapus Aditya");

        list.delete("2902795211");

        list.display();

        end = System.nanoTime();

        System.out.println("Waktu Linked List : " + (end-start)+" ns");

    }
}