package queue;

import java.util.LinkedList;
import java.util.Queue;

public class CustomerQueue {

    private Queue<String> queue = new LinkedList<>();

    // Menambah pelanggan
    public void addCustomer(String name) {
        queue.offer(name);
        System.out.println(name + " berhasil masuk antrean.");
    }

    // Melayani pelanggan
    public void serveCustomer() {
        if (queue.isEmpty()) {
            System.out.println("Antrean kosong.");
        } else {
            System.out.println("Melayani pelanggan: " + queue.poll());
        }
    }

    // Menampilkan antrean
    public void showQueue() {
        if (queue.isEmpty()) {
            System.out.println("Antrean kosong.");
            return;
        }

        System.out.println("Daftar Antrean:");

        int no = 1;
        for (String customer : queue) {
            System.out.println(no++ + ". " + customer);
        }
    }
}