package linkedlist;

public class StudentLinkedList {

    private Node head;

    // Tambah mahasiswa
    public void add(Student student) {

        Node newNode = new Node(student);

        if (head == null) {
            head = newNode;
            return;
        }

        Node temp = head;

        while (temp.next != null)
            temp = temp.next;

        temp.next = newNode;
    }

    // Hapus mahasiswa
    public void delete(String nim) {

        if (head == null)
            return;

        if (head.data.getNim().equals(nim)) {

            head = head.next;

            return;
        }

        Node temp = head;

        while (temp.next != null &&
                !temp.next.data.getNim().equals(nim)) {

            temp = temp.next;
        }

        if (temp.next != null)
            temp.next = temp.next.next;
    }

    // Update nilai
    public void update(String nim, int nilaiBaru) {

        Node temp = head;

        while (temp != null) {

            if (temp.data.getNim().equals(nim)) {

                temp.data.setNilai(nilaiBaru);

                return;
            }

            temp = temp.next;
        }

    }

    // Menampilkan data
    public void display() {

        Node temp = head;

        int no = 1;

        while (temp != null) {

            System.out.println(no++
                    + ". NIM : "
                    + temp.data.getNim()
                    + " Nama : "
                    + temp.data.getNama()
                    + " Nilai : "
                    + temp.data.getNilai());

            temp = temp.next;
        }
    }
}